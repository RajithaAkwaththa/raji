<?php

	require_once("../conn/conn.php");
	include("../conn/login_con.php");
		
		if(isset($_COOKIE['id']))	 {
			
		$id = $_COOKIE['id'];
		$selectQry = $conn->prepare("select priv_level from user_login where user_id = ? ");
		$selectQry->bind_param("s",$id);

			$selectQry->execute();
			$selectQry->bind_result($priv_level);
			mysqli_stmt_fetch($selectQry);

		}
		else{
			header('Location: index.php');
		}

	if(!isset($_COOKIE['id']) || $priv_level != 3){
		header('Location: index.php');
	}
?>
	<!doctype html>
<html>
<head>
	<title> Welcome Local User 
	<?php 
		require_once("../conn/conn.php");
		include("../conn/login_con.php");
		
		
		
	?> 
	</title>
	
	<link rel="stylesheet" type="text/css" href="../css/css_fonts.css">
	<link rel="stylesheet" type="text/css" href="../css/css_login.css">
	<link rel="stylesheet" type="text/css" href="../css/css_buttons.css">


	
	
</head>

<body >


<div align='right'  >
		<a href="../logout.php" > Log Out </a>
</div>
<div align='right'  >
<a href="https://drive.google.com/open?id=0B9g8bMuOeCr3WUlFOEY4ZktxVHc" download > flag 5</a>
</div>

<hr/>



</body>
</html>
