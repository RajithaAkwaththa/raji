<!doctype html>
<html>
<?php
	require_once("conn/conn.php");
	include("conn/login_con.php");

	if(isset($_COOKIE['id']) )	 {
			
		$id = $_COOKIE['id'];
			if($id == 1){
			$selectQry = $conn->prepare("select priv_level from user_login where user_id = ? ");
			$selectQry->bind_param("s",$id);

			$selectQry->execute();
			$selectQry->bind_result($priv_level);
			mysqli_stmt_fetch($selectQry);	
			}
			else{
				header('Location: index.php');
				}	

		}
		else{
			header('Location: index.php');
		}

	if(!isset($_COOKIE['id']) || $priv_level != 0){
		header('Location: index.php');
	}
	
?>

<head>
	<title> Welcome Administrator 
	
	</title>
	
	<link rel="stylesheet" type="text/css" href="css/css_fonts.css">
	<link rel="stylesheet" type="text/css" href="css/css_login.css">
	<link rel="stylesheet" type="text/css" href="css/css_buttons.css">
	
</head>

<body >






<div float="right" >


<form name = "search_bar" id = "search_bar" action="" method = "POST" >
		<table align="right">
			<tr>
				<td>  </td>
				<td>
					<input type="text" id="search" align="right" name="search" size="40"  ></input>	
				</td>
				
			</tr>
			
			<tr align ='right'>
				<td colspan ="2">
					<input class = 'submit' type = 'submit' value ='Search' name = 'Search' id= 'Search' />		
				</td>				
			</tr>
		
		</table>
	</form>
</div>
<br>
<br>
<br>

<div align="right">

		<a href="logout.php" align="right"> Log Out </a>
</div>

<div align="right">

		<a href="https://drive.google.com/open?id=0B9g8bMuOeCr3WUlFOEY4ZktxVHc" download > flag 5</a></div>
<div > 
<center>
 <h3 >Welcome Admin !!!</h3>
 
 <hr/ >
</div>
</center>
<div>
 <h3 >News about cyber security </h3>
 
 <hr/ >
	
	
		<?php
		//search();
		
		
		if(!isset($_POST['Search'])){
		
		//$search=$_POST['search'];
		$selectQry = "SELECT * FROM `articles`  ";
		
	
		$resultSet = mysqli_query($conn, $selectQry);
		?>
		<table  border="1px">
		<?php
		
		while($row = $resultSet->fetch_row()){
			?>
			
			
				<tr>
					<td >
			<?php
			echo $row[1];?>
				</td>
					</tr>
			
				<tr>
					<td >
			<?php
			echo $row[2];?>
				</td>
					</tr>
					
			<?php
		}?>
		
		</table>
	<?php
		
	}?>
	
	<?php
		if(isset($_POST['Search'])){
		
		$search=$_POST['search'];
		$selectQry = "SELECT * FROM `articles` where topic like '%".$search."%' ";
		
	
		$resultSet = mysqli_query($conn, $selectQry);
		?>
		<table  border="1px">
		<?php
		
		while($row = $resultSet->fetch_row()){
			?>
			
			
				<tr>
					<td >
			<?php
			echo $row[1];?>
				</td>
					</tr>
			
				<tr>
					<td >
			<?php
			echo $row[2];?>
				</td>
					</tr>
					
			<?php
		}?>
		
		</table>
	<?php
		
	}
	
	?>
</div>
</body>
</html>
