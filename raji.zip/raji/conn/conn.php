<?php 	
	

	require_once("login_con.php");

	$conn = mysqli_connect($db_host, $db_usr, $db_pwd) or die ("error".mysqli_connect_error());
	
if(mysqli_select_db($conn, "ctf_db")){
		
//echo "Database selected";
	
}
else{
		
//echo "error".mysqli_error($conn);
	
}
	
if(!$conn){
		

		//die("error!");
	
}else{
		
//echo "success conne";
	}

	//echo "NUll conne";

?>

