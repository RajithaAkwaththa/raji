<?php
	$db_host = "localhost";
	$db_usr = "root";
	$db_pwd = "";
	$db_name = "ctf_db";
?>
