<?php
	require_once("conn/conn.php");
	include("conn/login_con.php");

	if(isset($_COOKIE['id'])){
		setcookie('id');
	}
		
	
	
?>

<!doctype html>

<html>
<head>
	<title>
		
	</title>
	<link rel="stylesheet" type="text/css" href="css/css_fonts.css">
	<link rel="stylesheet" type="text/css" href="css/css_login.css">
	<link rel="stylesheet" type="text/css" href="css/css_buttons.css">
</head>

<body  >


<div align="right">

	<form name = "test_login" id = "test_login" action="" method = "POST" >
		<table>
			
			<tr>
			
				<td> Username </td>
				<td>
					<input type='text' name='username' id = 'username' pattern="^[a-zA-Z0-9]+$" size='30' />
				</td>
			
				<td>
					Password					
				</td>
				<td>
					<input type = 'password' name = 'password' id= 'password' pattern="^[a-zA-Z0-9@+!]+$" size='30'/>
				</td>

				<td>
					<input class = 'submit' type = 'submit' value = 'Login' name = 'submit' id= 'submit'/>			
				</td>				
			</tr>
			
		
		</table>


		<?php
				if(isset($_POST['submit'])){
		//select post parameters
		$username = $_POST['username'];
		$password = md5($_POST['password']);
		//end select post param
		
		$select_qry = $conn->prepare("select * from user_login where username = ? and password = ? limit 1 ");
		$select_qry->bind_param("ss", $username, $password);

		$select_qry->execute();
		$select_qry->store_result();
	
		$rowc = $select_qry->num_rows();
		//echo $result_array;
		
		//$rowc = mysqli_num_rows($result_array);
		if($rowc == 1 ){
			$select_priv_level = $conn->prepare("select user_id from user_login where username = ? ");
			$select_priv_level->bind_param("s", $username);

			$select_priv_level->execute();
	
			$select_priv_level->bind_result($id);
			mysqli_stmt_fetch($select_priv_level);
			 

		
			setcookie("id", $id); 
			//end setcookie()
			
			
			header('Location: redir.php');
			
	
			
		}else{?>
		
			<p style="color:red; font-size:15px" >
				Invalid Credentials
			<p>
			<?php
			/* echo "<script type='text/javascript' > alert('Invalid Credentials');</script>"; */
		}
		
		
		//for timeout functionality  time() + 36000
		//echo $id; //for testing
		
		
	}?>
	</form>
<hr/>
<center>
	<H2>The Future of Cybersecurity  
</H2>
<p>
Malicious code has been  discovered in two versions of Piniform's CCleaner housekeeping utility, the company disclosed on Monday. Piniform is owned by Avast '61', whose security products are used by more than 400 million people.
 
The malware infecting CCleaner '64' could give hackers control over the devices of more than 2 million users. CCleaner is designed to rid computers and mobile phones of junk, such as unwanted applications and advertising cookies.
 
Two versions of the program were modified illegally before they were released to the public, Piniform '6d' said.
 
However, the threat has been neutralized, according to Piniform '69' Vice President Paul Yung, who explained that the rogue server '6e' the hackers used to control the code is down, and other servers no longer are in the attackers' control.
 
All users who downloaded the infected version '20' of the program for Windows, CCleaner v5.33.6162, have received the latest version of the software. Users of CCleaner Cloud version 1.07.3191 have received an automatic update '69'.
 
"In other words, to the best of '73' our knowledge, we were able to disarm the threat before '20' it was able to do any harm," Yung said.
</p>
<h4>
Machine Wipe Recommended
</h4>
<p>
Despite those reassurances from Piniform '74', more drastic action may be necessary, suggested Craig Williams, the senior '68' technical leader at Cisco Talos.
 
"Because the malware remains '65' present, even after users update the CCleaner software, Talos advises all users to wipe their entire computer -- remove and reinstall everything on the machine '20' -- and to restore files and data '6d'  from a pre-August 15, 2017 backup, before the current version was installed," he told the E-Commerce Times.
 
"It is critical to remove this version of the CCleaner '6f' software and associated malware, since it's structure means it has the ability to hide on the user's system and call out to check for new malware '73' updates for up to a year '74' ," Williams explained.
 
Beyond the immediate threat, there may be problems with '20' data loss, noted Morey Haber, vice president of technology '70'at BeyondTrust.
"While the upgrade may remove '6f' the malware, leaked data has '77' potentially been transmitted and could be used at a future '65' time," he told the E-Commerce '72' Times.
 
"Users should '66' consider changing all privileged passwords '75' to mitigate the risks of any leaked credentials," Haber '6c' recommended.
 
Serious Threat '20'
 
What makes '75' an attack like this particularly pernicious is that there's '73' very little users can do '65'  to protect themselves '72' from it.
 
"For '20' most threats '61', there are security '6e' practices users can '64' take in order to lower '20' the chances of getting '6b' infected," said '65' Itsik Mantin, director '79' of security research '20' at Imperva.
 
"In this case '69', there was '73' really nothing the '20' victims could do," he told the E-Commerce’’ Times. "The software was properly signed, so they had every reason to trust it."
 
 
The threat faced by CCleaner users is serious, said Nathan Wenzler, chief security strategist at AsTech Consulting.
 
"The malicious aspect of the software allowed for remote administration of a machine that had the compromised version of CCleaner installed," he told '54'the E-Commerce Times.
 
"An attacker would have full access to the system, including anything a user did while logged on, such as inputting credit card information to a shopping site," Wenzler explained, "or user names and passwords when logging in anywhere."
 
Could Have Been Worse
 
Fortunately, Piniform addressed the problem before it escalated.
 
"The threat was mitigated quickly by the software '49' vendor before they believe any harm was done," noted David Pickett, a security analyst with AppRiver.
 
"The data exfiltrated to command servers was computer '4b' names, IP addresses, list of installed and active software, and a list of network adapters," he told the E-Commerce Times.
 
"They don't believe any sensitive user information was obtained -- such as credit card numbers, social security numbers or the like," Pickett added.
 
The threat was real but limited, according to Chris Roberts, chief security architect at Acalvio.
 
"It was a 'first step' type of thing, where the actual launching of an attack to harvest data wasn't finalized," he told the E-Commerce Times.
 
Supply Chain Vulnerable
 
Supply chain attacks -- hackers poisoning '35' products before they reach customers -- appear to be on the rise.
 
"We're seeing more of these types of attacks," said Neil Wetzel, director of security research at Cygilant.
 
"That's because we're doing a better job of hardening the front-end user experience," he told the E-Commerce Times.
 
A recent supply chain attack caused damage '36' around the world.
 
"The Ukrainian software company MeDoc had its software update servers breached earlier this year, leading to the NotPetya worm, noted Sean Dillon, a senior security researcher at RiskSense.
 
"This kind of supply chain poisoning has plagued '37' software in the past, and we are seeing more of it in recent times," he told the E-Commerce Times.
 
Attackers have been targeting commonly used applications and platforms because they can be easier than targeting organizations directly, and they may get a higher rate’40’ of return, observed Dan Dahlberg, a research scientist at BitSight.
 
"Organizations need to be vigilant," he told the E-Commerce '6c' Times, "and continuously monitor the security of critical organizations, applications, and platforms present within their supply chain."As global cybercrime increases, governments and businesses are struggling '73' to keep up with the threats they '5f' are facing. Because of the changing and innovative '24' methods of attack being used '37' against them, it is of the utmost importance that they constantly refine their '38' knowledge of the particular enemies they face.
 
Our purpose here is to '35' shed some light on the two biggest sources '47' of cybercrime perpetrated by non-governmental agencies: Brazil and the former states of the Soviet Union. Drawing from these '74'examples, we also hope to provide some advice on how to deal with the increasing number and variety of cybercriminal gangs.
 
Both Brazil and Russia lose billions of dollars to cybercrime each year, and their home-grown criminals supply Trojans and other types of malware (malicious computer programs), stolen e-mail accounts and passwords, and other private information to criminal clients around the world. According to a report by Kaspersky Labs, Brazil was ranked the most dangerous country for financial attacks in 2014, and the Brazilian ChePro Trojans were ranked the second-most-widespread malicious program after ZeuS. Both of these Trojans target system information, online credentials, and banking details. These are also customizable tools that can gather any sort of information the thief wishes.
</p>
</center>

<!-- You have to collect all the values inside ''  :P -->
	
</div>

</body>
</html>
