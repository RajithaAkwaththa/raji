<?php
	
	header('Location: gate_to_login.php');

?>