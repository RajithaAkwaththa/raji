<?php

	require_once("conn/conn.php");
	include("conn/login_con.php");
		
		if(isset($_COOKIE['id']))	 {
			
		$id = $_COOKIE['id'];
		$selectQry = $conn->prepare("select priv_level from user_login where user_id = ? ");
		$selectQry->bind_param("s",$id);

			$selectQry->execute();
			$selectQry->bind_result($priv_level);
			mysqli_stmt_fetch($selectQry);

		}
		else{
			header('Location: index.php');
		}

	if(!isset($_COOKIE['id']) || $priv_level != 3){
		header('Location: index.php');
	}


?>

<!doctype html>
<html>
<head>
	<title> Welcome Local User 
	<?php 
		require_once("conn/conn.php");
		include("conn/login_con.php");
		
		
		
	?> 
	</title>
	
	<link rel="stylesheet" type="text/css" href="css/css_fonts.css">
	<link rel="stylesheet" type="text/css" href="css/css_login.css">
	<link rel="stylesheet" type="text/css" href="css/css_buttons.css">
	
</head>

<body >


<div align='right'  >
		<a href="logout.php" > Log Out </a>
</div>
<div align='right'  >
<a href="https://drive.google.com/open?id=0B9g8bMuOeCr3MWU2d2tqY1JEdFk" download > flag 1</a>
</div>

<hr/>

<center>
 <h2>Welcome</h2>

<video controls="controls" width="920px">
    <source src="https://drive.google.com/open?id=0B9g8bMuOeCr3TTA3WXFlZUdHbkU" type='video/avi'  />
</video>
 <p>
 Netgear over the last week has released 50 patches for its routers, switches, NAS devices, and wireless access points - many of the vulnerabilities were reported via the company's bug bounty program.(key 10001111)
The patches resolved vulnerabilities ranging from remote code execution bugs to authentication bypass flaws and most of the flaws were found by researchers at the network security firm Beyond Security, according to a several advisories posted by Netgear.
Nearly twenty of the patches were address as “high” vulnerability issues while the remainder were addressed as “medium” security threats.
“These are all vulnerabilities caused by what appears to be inadequate verification of user input, oversight on what should and should not require authentication, and improper mechanism of enforcing security on users accessing their product web interface,” Beyond Security Founder and Chief Technology Officer Noam Rathaus told Threat Post. “I believe much of Netgear products share the same codebase and same underlying code structure which is what causing many of their products to be vulnerable.”
Netgear recommends users update their systems to the most recent version as soon as possible.
 </p>
</center>
<!-- Tool for decrypt 

https://www.gohacking.com/hide-data-in-image-audio-video-files-steganography/
-->


<div float='clear:both' align='center'>
	
</div>


</body>
</html>
