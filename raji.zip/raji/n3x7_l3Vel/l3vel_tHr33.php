<?php

	require_once("../conn/conn.php");
	include("../conn/login_con.php");
		
		if(isset($_COOKIE['id']))	 {
			
		$id = $_COOKIE['id'];
		$selectQry = $conn->prepare("select priv_level from user_login where user_id = ? ");
		$selectQry->bind_param("s",$id);

			$selectQry->execute();
			$selectQry->bind_result($priv_level);
			mysqli_stmt_fetch($selectQry);

		}
		else{
			header('Location: index.php');
		}

	if(!isset($_COOKIE['id']) || $priv_level != 3){
		header('Location: index.php');
	}
?>
	<!doctype html>
<html>
<head>
	<title> Welcome Local User 
	<?php 
		require_once("../conn/conn.php");
		include("../conn/login_con.php");
		
		
		
	?> 
	</title>
	
	<link rel="stylesheet" type="text/css" href="../css/css_fonts.css">
	<link rel="stylesheet" type="text/css" href="../css/css_login.css">
	<link rel="stylesheet" type="text/css" href="../css/css_buttons.css">

	<script src="jquery-3.2.1.js"></script>
	<script src="script.js"></script>

	
	
</head>

<body >


<div align='right'  >
		<a href="../logout.php" > Log Out </a>
</div>
<div align='right'  >
<a href="https://drive.google.com/open?id=0B9g8bMuOeCr3ZFRpczh4RkRDelU" download > flag 3</a>
</div>

<hr/>

<div class="container">
     <h4>Number Puzzle </h4>
     <ul class="puzzle">
          <li><span>6</span></li>
          <li><span>1</span></li>
          <li><span>3</span></li>
          <li><span>2</span></li>
          <li><span>5</span></li>
          <li><span>4</span></li>
          <li><span>2</span></li>
          <li><span>3</span></li>
          <li><span>1</span></li>
          <li><span>7</span></li>
          <li><span>5</span></li>
          <li><span>8</span></li>
          <li><span>4</span></li>
          <li><span>8</span></li>
          <li><span>6</span></li>
          <li><span>7</span></li>
          <li><span>6</span></li>
          <li><span>1</span></li>
          <li><span>3</span></li>
          <li><span>2</span></li>
          <li><span>5</span></li>
          <li><span>4</span></li>
          <li><span>2</span></li>
          <li><span>3</span></li>
          <li><span>1</span></li>
          <li><span>7</span></li>
          <li><span>5</span></li>
          <li><span>8</span></li>
          <li><span>4</span></li>
          <li><span>8</span></li>
          <li><span>6</span></li>
          <li><span>7</span></li>
          <li><span>6</span></li>
          <li><span>1</span></li>
          <li><span>3</span></li>
          <li><span>2</span></li>
          <li><span>5</span></li>
          <li><span>4</span></li>
          <li><span>2</span></li>
          <li><span>3</span></li>
          <li><span>1</span></li>
          <li><span>7</span></li>
          <li><span>5</span></li>
          <li><span>8</span></li>
          <li><span>4</span></li>
          <li><span>8</span></li>
          <li><span>6</span></li>
          <li><span>7</span></li>
          <li><span>6</span></li>
          <li><span>1</span></li>
          <li><span>3</span></li>
          <li><span>2</span></li>
          <li><span>5</span></li>
          <li><span>4</span></li>
          <li><span>2</span></li>
          <li><span>3</span></li>
          <li><span>1</span></li>
          <li><span>7</span></li>
          <li><span>5</span></li>
          <li><span>8</span></li>
          <li><span>4</span></li>
          <li><span>8</span></li>
          <li><span>6</span></li>
          <li><span>7</span></li>
     </ul>
     <h4 class="congrates" style="display: none;">Congratulations! You Complete the puzzle.</h4>
</div>

</body>
</html>
