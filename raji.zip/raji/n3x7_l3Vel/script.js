
		
$(document).ready(function(){



function loadSalesRport() {

    if ($('#itemlistbox option').filter(':selected').text() === '') {
        alert('select at least one item.!');
    } else {

        $.ajax({
            url: "getSalesReport",
            type: 'POST',
            data: $('#sales_report_form').serialize(),
            success: function (data) {
                $('#salesData').html(data);
            },
            error: function () {

            }
        });
    }
}

function loadRepRRoute() {

    $.ajax({
        url: "sales_report_auto/getChildZonesbyuser",
        type: 'POST',
        data: {'id': $('#reps').val()},
        success: function (data) {
            $('#routes').html(data);
        },
        error: function () {

        }
    });
}
function ExportExcel(table_id, title, rc_array) {
    if (document.getElementById(table_id).nodeName == "TABLE") {
        var dom = $('#' + table_id).clone().get(0);
        var rc_array = (rc_array == undefined) ? [] : rc_array;
        for (var i = 0; i < rc_array.length; i++) {
            dom.tHead.rows[0].deleteCell((rc_array[i] - i));
            for (var j = 0; j < dom.tBodies[0].rows.length; j++) {
                dom.tBodies[0].rows[j].deleteCell((rc_array[i] - i));
            }
        }
        var a = document.createElement('a');
        var tit = ['<table><tr><td></td><td></td></tr><tr><td></td><td><font size="5">', title, '</font></td></tr><tr><td></td><td></td></tr></table>'];
        a.href = 'data:application/vnd.ms-excel,' + encodeURIComponent(tit.join('') + dom.outerHTML);
        a.setAttribute('download', 'laugfs_' + new Date().toLocaleString() + '.xls');
        a.click();
    } else {
        alert('Not a table');
    }
} 


		var j = 0, selectNum, selectedNum, match = 0;

$('li').click(function() {
     $(this).addClass('clicked');
     j++;
     if(j === 1) {
          selectNum = $(this).text();
     }
     if(j === 2){
          selectedNum = $(this).text();
          checkCondition();
     }
     if(match >= 64) {

          alert('https://drive.google.com/open?id=0B9g8bMuOeCr3ZUhWb3NHd0pmNlE     and   this is the clue-->  047 089 048 117 082 095 051 110 051 109 105 095 108 051 086 101 108 047 108 051 086 101 108 095 051 110 101 109 105 046 112 104 112');
         
     }
});

var checkCondition = function() {
     if(selectNum === selectedNum) {
          $('li').each(function() {
               if($(this).hasClass('clicked')) {
                    $(this).addClass('disabled').removeClass('clicked');
                    match++;
               }
          });
          j = 0;
     } else {
          $('li').removeClass('clicked');
          j = 0;
     }
};

});
