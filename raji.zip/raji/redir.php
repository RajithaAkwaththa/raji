<?php

	require_once("conn/conn.php");
	include("conn/login_con.php");
	
	if(isset($_COOKIE['id']) ){
		$id = $_COOKIE['id'];
		
		$priv_level = 3;
		$selectQry = $conn->prepare("select priv_level from user_login where user_id = ? ");
		$selectQry->bind_param("s",$id);

		$selectQry->execute();
		
	
		$selectQry->bind_result($priv_level);
			mysqli_stmt_fetch($selectQry);
		if($priv_level == 0){
				
				header('Location: admin_gate.php');
		}else if($priv_level == 3){
				
				header('Location: local_home.php');
		}
		
		
	}else{
	}


?>
